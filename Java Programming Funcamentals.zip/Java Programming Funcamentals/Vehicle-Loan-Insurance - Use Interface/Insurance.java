public interface Insurance {
    double takeInsurance();
}
