public interface Spatial {
}
