public interface MaintenanceCharge {
    float calculateMaintenanceCharge(float noOfYears);
}
